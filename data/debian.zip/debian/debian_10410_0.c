int tm_dealloc ( tm_node_id node , tm_event_t * event ) {
 if ( ! init_done ) return TM_BADINIT ;
 return TM_ENOTIMPLEMENTED ;
 }