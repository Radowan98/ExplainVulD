int tm_alloc ( char * resources , tm_event_t * event ) {
 if ( ! init_done ) return TM_BADINIT ;
 return TM_ENOTIMPLEMENTED ;
 }