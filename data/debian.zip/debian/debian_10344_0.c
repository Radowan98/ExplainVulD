static const char * Indent ( guint8 level ) {
 return indent_buffer + ( 512 - 2 * ( level ) ) ;
 }