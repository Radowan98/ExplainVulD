int tm_destroy_event ( tm_event_t * event ) {
 if ( ! init_done ) return TM_BADINIT ;
 return TM_ENOTIMPLEMENTED ;
 }