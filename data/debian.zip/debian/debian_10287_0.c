static void cmd_channel_add ( const char * data ) {
 cmd_channel_add_modify ( data , TRUE ) ;
 }