static void cmd_network_add ( const char * data ) {
 cmd_network_add_modify ( data , TRUE ) ;
 }