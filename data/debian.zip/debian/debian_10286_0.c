static void cmd_channel_modify ( const char * data ) {
 cmd_channel_add_modify ( data , FALSE ) ;
 }