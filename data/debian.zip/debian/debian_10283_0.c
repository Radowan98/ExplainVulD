static void cmd_network_modify ( const char * data ) {
 cmd_network_add_modify ( data , FALSE ) ;
 }