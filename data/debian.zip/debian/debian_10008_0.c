static int dissect_zbee_zcl_ballast_configuration ( tvbuff_t * tvb _U_ , packet_info * pinfo _U_ , proto_tree * tree _U_ , void * data _U_ ) {
 return tvb_captured_length ( tvb ) ;
 }