static void finalize_request ( ngx_http_request_t * r , ngx_int_t rc ) {
 ngx_log_debug0 ( NGX_LOG_DEBUG_HTTP , r -> connection -> log , 0 , "finalize Passenger request" ) ;
 }