static void cmd_server_modify ( const char * data ) {
 cmd_server_add_modify ( data , FALSE ) ;
 }