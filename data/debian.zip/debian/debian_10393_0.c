int tm_register ( tm_whattodo_t * what , tm_event_t * event ) {
 if ( ! init_done ) return TM_BADINIT ;
 return TM_ENOTIMPLEMENTED ;
 }