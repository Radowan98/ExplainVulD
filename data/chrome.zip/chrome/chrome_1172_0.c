IN_PROC_BROWSER_TEST_F ( VirtualKeyboardBrowserTest , HideKeyboardKeyTest ) {
 RunTest ( base : : FilePath ( FILE_PATH_LITERAL ( "hide_keyboard_key_test.js" ) ) ) ;
 }