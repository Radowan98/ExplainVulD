static const char * ultag_getPrivateUse ( const ULanguageTag * langtag ) {
 return langtag -> privateuse ;
 }