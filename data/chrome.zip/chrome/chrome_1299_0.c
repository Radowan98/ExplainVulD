static const char * ultag_getLanguage ( const ULanguageTag * langtag ) {
 return langtag -> language ;
 }