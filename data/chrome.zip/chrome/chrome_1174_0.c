IN_PROC_BROWSER_TEST_F ( VirtualKeyboardBrowserTest , TypingTest ) {
 RunTest ( base : : FilePath ( FILE_PATH_LITERAL ( "typing_test.js" ) ) ) ;
 }