static UBool U_CALLCONV lenient8IteratorHasPrevious ( UCharIterator * iter ) {
 return iter -> start > 0 ;
 }