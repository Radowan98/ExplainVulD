IN_PROC_BROWSER_TEST_F ( VirtualKeyboardBrowserTest , DISABLED_AttributesTest ) {
 RunTest ( base : : FilePath ( FILE_PATH_LITERAL ( "attributes_test.js" ) ) ) ;
 }