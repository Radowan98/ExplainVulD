bool RegisterPolicyAuditor ( JNIEnv * env ) {
 return RegisterNativesImpl ( env ) ;
 }