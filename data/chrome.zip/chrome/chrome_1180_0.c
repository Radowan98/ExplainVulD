static __inline__ __u64 ethtool_get_flow_spec_ring ( __u64 ring_cookie ) {
 return ETHTOOL_RX_FLOW_SPEC_RING & ring_cookie ;
 }