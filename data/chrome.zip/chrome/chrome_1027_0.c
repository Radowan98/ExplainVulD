void usage_exit ( ) {
 exit ( EXIT_FAILURE ) ;
 }