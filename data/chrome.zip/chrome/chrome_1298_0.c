static const char * ultag_getRegion ( const ULanguageTag * langtag ) {
 return langtag -> region ;
 }