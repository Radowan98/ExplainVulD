IN_PROC_BROWSER_TEST_F ( ExternalProtocolDialogBrowserTest , InvokeDialog_default ) {
 RunDialog ( ) ;
 }