extern int main ( int argc , const char * argv [ ] ) {
 TestLenient8Iterator ( ) ;
 return 0 ;
 }