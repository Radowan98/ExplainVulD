static const char * U_CALLCONV _CompoundTextgetName ( const UConverter * cnv ) {
 ( void ) cnv ;
 return "x11-compound-text" ;
 }