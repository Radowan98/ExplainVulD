static void U_CALLCONV _CompoundTextReset ( UConverter * converter , UConverterResetChoice choice ) {
 ( void ) converter ;
 ( void ) choice ;
 }