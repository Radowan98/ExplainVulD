static const char * ultag_getScript ( const ULanguageTag * langtag ) {
 return langtag -> script ;
 }