IN_PROC_BROWSER_TEST_F ( VirtualKeyboardBrowserTest , ControlKeysTest ) {
 RunTest ( base : : FilePath ( FILE_PATH_LITERAL ( "control_keys_test.js" ) ) ) ;
 }