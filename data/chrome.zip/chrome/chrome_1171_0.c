IN_PROC_BROWSER_TEST_F ( VirtualKeyboardBrowserTest , KeysetTransitionTest ) {
 RunTest ( base : : FilePath ( FILE_PATH_LITERAL ( "keyset_transition_test.js" ) ) ) ;
 }